<?php 

require_once 'koneksi.php';

$aktif = 'kontak'; 
?>

		<!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
	  <link rel="stylesheet" href="resources/fonts/stylesheet.css">
	  <link rel="icon" type="icon" href="img/g.png"> 
      <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <style>
        .slider h3,
        .slider h5,
        .clients h3 {
          text-shadow: 1px 1px 3px rgba(0,0,0,0.5);
      }
      .parallax-container {
        height: 240px;
      }
      .parallax img{
        filter: grayscale(1);
        opacity: 0.5 !important;
      }

	  
      </style>
      <title>Jericho</title>
    </head>

    <body>
      
      <!-- Navbar -->
       <div class="navbar-fixed">
    <nav class="blue darken-2">
      <div class="container"> 
      <div class="nav-wrapper">
        <a href="#!" class="brand-logo">Jericho</a>
        <a href="#" data-target="mobile-nav" class="sidenav-trigger"><i class="material-icons">menu</i></a>
        <ul class="right hide-on-med-and-down">
          <?php include 'navbar.php'; ?>
        </ul>
      </div>
    </nav>
  </div>
</div>


	
<section id="contact" class="contact">
	  <div class="container">
	  	<h3 class="light grey-text text-darken-3 center">Contact US</h3>
		  <div class="row">
	  			<div class="col m5 s12">
				  <div class="card panel blue darken-2 center white-text">
	  				<i class="material-icons medium">email</i>
					  <h5>Hubungi Kami</h5>
					  <p>Hubungi kami kapan saja, kami senang untuk memberikan dukungan penuh kepada Anda!</p><br>
				  </div>
				  <ul class="collection with-header">
	  				<li class="collection-header center"><h4>Our Office</h4></li>
					<li class="collection-item">Jericho</li>
					<li class="collection-item">JL. ARRIDHO NO. 166 RT. 001/004 Kel/Kec. Jatimulya - Cilodong Kota Depok</li>
					<li class="collection-item">Jawa Barat, Indonesia</li>
				  </ul>	
				</div>

				<div class="col m7 s12">
	  				<form action="pesan.php" method="post">
	  					<div class="card-panel">
						  <h5>Isi form dibawah ini.</h5>
						  <?php if(isset($_SESSION['sukses'])) : ?>
								<div id="card-alert" class="card green lighten-5">
								<div class="card-content green-text">
									<p><?= $_SESSION['sukses'] ?></p>
								</div>
								</div>
								<?php unset($_SESSION['sukses']) ?>
								<?php elseif(isset($_SESSION['gagal'])) : ?>
								<div class="card-panel">
									<div  id="card-alert" class="card red lighten-5">
										<strong>Gagal!</strong> <?= $_SESSION['gagal'] ?>
										<button type="button" class="close" data-dismiss="alert" aria-label="Close">
											<span aria-hidden="true">&times;</span>
										</button>
									</div>
									</div><br>
								<?php unset($_SESSION['gagal']) ?>
								<?php endif; ?>
						  <div class="input-field">
							<input type="text" name="nama" id="nama" required class="validate">
							<label for="nama">Nama</label>
						  </div>
						  <div class="input-field">
							<input type="email" name="email" id="email" class="validate"> 
							<label for="email">email</label>
						  </div>
						  <div class="input-field">
							<input type="text" name="notlp" id="notlp" required class="validate">
							<label for="notlp">No.Telp</label>
						  </div>
						  <div class="input-field">
							<textarea name="pesan" id="pesan" class="materialize-textarea" required class="validate"></textarea>
							<label for="pesan">Pesan</label>
						  </div>
						  <button type="submit" name="tambah" class="btn blue darken-2">Kirim!<i class="material-icons right">send</i></button>
						</div>
					</form>
				</div>
		  </div>
	  </div>
</section>
	  	
<script src="http://maps.googleapis.com/maps/api/js"></script>
<script>
function initialize() {
  var propertiPeta = {
    center:new google.maps.LatLng(-6.4464194,106.8280174),
    zoom:9,
    mapTypeId:google.maps.MapTypeId.ROADMAP
  };
  
  var peta = new google.maps.Map(document.getElementById("googleMap"), propertiPeta);
  
  // membuat Marker
  var marker=new google.maps.Marker({
      position: new google.maps.LatLng(-6.4464194,106.8280174),
      map: peta,
      animation: google.maps.Animation.BOUNCE
  });

}

// event jendela di-load  
google.maps.event.addDomListener(window, 'load', initialize);
</script>
</section>
<div class="title mb-3">
				 <br>
					<h3 class="center"><b>Our Location </b></h3>
				</div>
				<div class="artikel">
                    <div id="googleMap" style="width:100%;height:380px;"></div>
				</div>
			</div>
<!-- <div class="row p-3">
		<div class="col m6 s12">
				<div class="title mb-3">
				 <br>
					<h3 class="center"><b>Our Location </b></h3>
				</div>
				<div class="artikel">
                    <div id="googleMap" style="width:100%;height:380px;"></div>
				</div>
			</div>
      </div>
    </div> -->
  

  
				
			</div>
			
		</div>
		<?php require 'footer.php';?>