
<footer class="page-footer blue darken-2">
          <div class="container">
            <div class="row">
              <div class="col l6 s12">
                <h5 class="white-text"><img src="img/f.png"></h5>
                <p class="grey-text text-lighten-4">Jericho - adalah jasa pembangunan website dan merupakan solusi yang tepat untuk anda yang ingin membangun website toko online, company profile, dan blog</p>
              </div>
              <div class="col l4 offset-l2 s12">
                <h5 class="white-text">Follow US</h5>
                <ul>
                  <li><a class="grey-text text-lighten-3" target="_blank" href="https://web.facebook.com/jerichowebsite.jerichowebsite">Facebook</a></li>
                  <li><a class="grey-text text-lighten-3" target="_blank" href="https://www.instagram.com/jericho.website/">Instagram</a>
                </ul>
              </div>
            </div>
          </div>
          <div class="footer-copyright">
            <div class="container">
            © 2021 Copyright By Bambang Dwi Bayusegara
            <a class="grey-text text-lighten-4 right" href="#!">More Links</a>
            </div>
          </div>
        </footer>
        
        <script type="text/javascript" src="materialize/js/materialize.min.js"></script>
      <script>
        //nav
        const sideNav = document.querySelectorAll('.sidenav');
        M.Sidenav.init(sideNav);


        //slider
        const slider = document.querySelectorAll('.slider');
        M.Slider.init(slider, {
          indicators: false,
          height: 500,
          transition: 600,
          interval: 3000
        });

        //parallax js
        const parallax = document.querySelectorAll('.parallax');
        M.Parallax.init(parallax);


        //galeri
        const materialbox = document.querySelectorAll(".materialboxed");
        M.Materialbox.init(materialbox);

      </script>
	

	<script src="resources/js/jquery.js"></script>
	<script src="resources/js/bootstrap.min.js"></script>
	<script src="resources/datatables/datatables.min.js"></script>
	<script src="resources/datatables/datatable.js"></script>
</body>
</html>
	