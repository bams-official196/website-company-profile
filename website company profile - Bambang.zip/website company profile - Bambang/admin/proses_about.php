<?php 

require_once '../koneksi.php';
require_once 'cek_session.php';
$about = mysqli_real_escape_string($koneksi, isset($_POST['about']) ? $_POST['about'] : '');
$visi_misi = mysqli_real_escape_string($koneksi, isset($_POST['visi_misi']) ? $_POST['visi_misi'] : '');
$query = mysqli_query($koneksi, "UPDATE tbl_about SET about = '$about', visi_misi = '$visi_misi' WHERE id_about = 1");

if($query){
	$_SESSION['sukses'] = 'Data berhasil Diubah!';
	header('Location: about.php');
} else {
	$_SESSION['gagal'] = 'Data Gagal Diubah!';
	header('Location: about.php');
}