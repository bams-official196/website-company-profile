<?php 

require_once 'koneksi.php';
$about = mysqli_query($koneksi, "SELECT * FROM tbl_about WHERE id_about = 1");
$about = mysqli_fetch_assoc($about);
$query = mysqli_query($koneksi, "SELECT * FROM tbl_artikel");
$aktif = 'home';
?>


<!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link rel="icon" type="icon" href="img/g.png"> 
	  <link rel="stylesheet" href="resources/fonts/stylesheet.css">
      <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <style>
        .slider h3,
        .slider h5,
        .clients h3 {
          text-shadow: 1px 1px 3px rgba(0,0,0,0.5);
      }
      .parallax-container {
        height: 240px;
      }
      .parallax img{
        filter: grayscale(1);
        opacity: 0.5 !important;
      }

      .clients img {
        max-width: 150px;
        filter: drop-shadow(1px 1px 1px rgba(0,0,0,0.8));
        margin:2px;
      }

      section{
        padding:20px 0;
      }
      </style>
      <title>Jericho</title>
    </head>

    <body>
      
      <!-- Navbar -->
       <div class="navbar-fixed">
    <nav class="blue darken-2">
      <div class="container"> 
      <div class="nav-wrapper">
        <a href="#!" class="brand-logo">Jericho</a>
        <a href="#" data-target="mobile-nav" class="sidenav-trigger"><i class="material-icons">menu</i></a>
        <ul id="mobile-nav" class="sidenav">
        <?php include 'navbar.php'; ?>
        </ul>
        <ul class="right hide-on-med-and-down">
          <?php include 'navbar.php'; ?>
        </ul>
      </div>
    </nav>
  </div>
</div>
		
		<div class="slider">
    <ul class="slides">
      <li>
        <img src="img/slider/5.png"> <!-- random image -->
        <div class="caption left-align">
          <h3>Welcome To Website Jericho</h3>
          <h5 class="light grey-text text-lighten-3">Jasa Pembuatan Web Hosting dan Terpercaya</h5>
        </div>
      </li>
      <li>
        <img src="img/slider/6.png"> <!-- random image -->
        <div class="caption right-align">
          <h3>Welcome To Website Jericho</h3>
          <h5 class="light grey-text text-lighten-3">Jasa Pembuatan Web Hosting dan Terpercaya</h5>
        </div>
      </li>
      <li>
        <img src="img/slider/7.png"> <!-- random image -->
        <div class="caption center-align">
          <h3>Welcome To Website Jericho</h3>
          <h5 class="light grey-text text-lighten-3">Jasa Pembuatan Web Hosting dan Terpercaya</h5>
        </div>
      </li>
    </ul>
  </div>

  <section class="about" id="about">
    <div class="container">
      <div class="row">
        <h3 class="center ligth">About US</h3>
		<hr>
        <div class="col">
          <h6 class="light"><?= $about['about']; ?></h6>
        </div>
      </div>
    </div>
  </section>

		<!-- content -->
<section class="services grey lighten-3" id="services">
    <div class="container">
      <div class="row">
        <h3 class="light center grey-text darken-3">Our Services</h3>
        <div class="col m4 s12">
      
          <div class="card-panel center">
          <i class="material-icons medium">desktop_windows</i>
              <h5>Web Development</h5>
              <p>Jericho menjual jasa pembuatan web</p>
              <button onclick="window.location.href='produk.php';" class="btn btn-primary">Check!</button>
          </div>
          </div>

          <div class="col m4 s12">
          <div class="card-panel center">
          <i class="material-icons medium">desktop_windows</i>
              <h5>Mobile Development</h5>
              <p>Jericho menjual jasa pembuatan aplikasi mobile</p>
              <strong>Coming soon..</strong>
          </div>
          </div>

          <div class="col m4 s12">
          <div class="card-panel center">
          <i class="material-icons medium">desktop_windows</i>
              <h5>Game Development</h5>
              <p>Jericho menjual jasa pembuatan Game</p>
              <strong>Coming soon..</strong>
          </div>

        </div>
      </div>
    </div>
  </section>



<section class="loker" id="loker">
      <div class="container">
        <div class="row">
        <h3 class="center light">Info Loker</h3>
        <hr>
        <div class="col">
        <p>Jericho membuka loker pekerjaan/magang dengan beberapa syarat...</p>
        <a href="kategori.php?id=13" class="btn blue darken-2 center">Check!</a>
        </div>
        </div>
      </div>
</section>

				

<div class="parallax-container">
    <div class="parallax"><img src="img/slider/34.png">
    </div>
    <div class="container clients">
      <h3 class="center light white-text">Our Clients</h3>
      <div class="row m4 center">
      <a target="_blank" href="http://traveloka.com"> <img src="img/clients/traveloka.png"></a>
       <a target="_blank" href="http://gojek.com"><img src="img/clients/gojek.png"></a>
       <a target="_blank" href="http://telkom.co.id"><img src="img/clients/telkom.png"></a>
        
       
      </div>
    </div>
  </div>


				
				
			</div>
			
		</div>
		<?php require 'footer.php';?>