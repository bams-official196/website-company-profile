<?php 

require_once 'koneksi.php';

$query = mysqli_query($koneksi, "SELECT * FROM tbl_about WHERE id_about = 1");
$about = mysqli_fetch_assoc($query);
$aktif = 'about'; 
?>
		<!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
	  <link rel="stylesheet" href="resources/fonts/stylesheet.css">
    <link rel="icon" type="icon" href="img/g.png"> 
      <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <style>
        .slider h3,
        .slider h5,
        .clients h3 {
          text-shadow: 1px 1px 3px rgba(0,0,0,0.5);
      }
      .parallax-container {
        height: 240px;
      }
      .parallax img{
        filter: grayscale(1);
        opacity: 0.5 !important;
      }
      </style>
      <title>Jericho</title>
    </head>

    <body>
      
      <!-- Navbar -->
       <div class="navbar-fixed">
    <nav class="blue darken-2">
      <div class="container"> 
      <div class="nav-wrapper">
        <a href="#!" class="brand-logo">Jericho</a>
        <a href="#" data-target="mobile-nav" class="sidenav-trigger"><i class="material-icons">menu</i></a>
        <ul class="right hide-on-med-and-down">
          <?php include 'navbar.php'; ?>
        </ul>
      </div>
    </nav>
  </div>
</div>


		<!-- nav bar -->
		<?php require_once 'navbar.php'; ?>


		<!-- content -->
		<section class="about" id="about">
    <div class="container">
      <div class="row">
        <h3 class="center ligth">About Us</h3>
		<hr>
        <div class="col">
          <h6 class="center light"><?= $about['about'] ?></h6>
        </div>
        <div class="col">
        <hr>
          <h6 class="light"><?= $about['visi_misi'] ?></h6>
        </div>
      </div>
    </div>
  </section>

				
				
			</div>
			
		</div>
		<?php require 'footer.php';?>