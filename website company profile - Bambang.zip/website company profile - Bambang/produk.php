
<!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
	  <link rel="stylesheet" href="resources/fonts/stylesheet.css">
    <link rel="icon" type="icon" href="img/g.png"> 
      <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <style>
        .slider h3,
        .slider h5,
        .clients h3 {
          text-shadow: 1px 1px 3px rgba(0,0,0,0.5);
      }
      .parallax-container {
        height: 240px;
      }
      .parallax img{
        filter: grayscale(1);
        opacity: 0.5 !important;
      }
      </style>
      <title>Product</title>
    </head>

    <body>
      
      <!-- Navbar -->
       <div class="navbar-fixed">
    <nav class="blue darken-2">
      <div class="container"> 
      <div class="nav-wrapper">
        <a href="#!" class="brand-logo">Jericho</a>
        <a href="#" data-target="mobile-nav" class="sidenav-trigger"><i class="material-icons">menu</i></a>
        <ul class="right hide-on-med-and-down">
          <?php include 'navbar.php'; ?>
        </ul>
      </div>
    </nav>
  </div>
</div>


		<!-- nav bar -->
		<?php require_once 'navbar.php'; ?>


		<!-- content -->
		<section class="services" id="services">
    <div class="container">
      <div class="row">
        <h3 class="light center grey-text darken-3">Web Development</h3>
        <div class="col m4 s12">
      
          <div class="card-panel center">
          <i class="material-icons medium">desktop_windows</i>
              <h5>Paket 1</h5>
              <strong>Rp 500.000</strong>
              <p>Gratis Domain web.id</p>
              <p>Hosting 500MB (30 foto kuota kerja)</p>
              <p>Free Whatsapp/Telepon</p>
              <p>Website SSL</p>
              <p>Template WP premium</p>
              <p>Perpanjangan Setiap Tahun Rp 500.000</p>
              <p>Bandwidth Unlimited</p>
              <p>Free support</p>
              <a class="btn blue darken-2" target="_blank" href="http://wa.me/081513460378?text=Saya%20mau%20beli%20paket%201">Hubungi Teknisi</a>
          </div>

        </div>
        <div class="col m4 s12">
      
          <div class="card-panel center">
          <i class="material-icons medium">desktop_windows</i>
              <h5>Paket 2</h5>
              <strong>Rp 1.000.000</strong>
              <p>Gratis Domain .com</p>
              <p>Hosting 3GB (70 foto kuota kerja)</p>
              <p>Free Banner dan Logo</p>
              <p>Pemasangan Google Map</p>
              <p>Free Whatsapp/Telepon</p>
              <p>Website SSL</p>
              <p>Template WP premium</p>
              <p>Perpanjangan Setiap Tahun Rp 600.000</p>
              <p>Bandwidth Unlimited</p>
              <p>Free support</p>
              <a class="btn blue darken-2" target="_blank" href="http://wa.me/081513460378?text=Saya%20mau%20beli%20paket%202">Hubungi Teknisi</a>
          </div>

        </div>
          <div class="col m4 s12">
            
            <div class="card-panel center">
            <i class="material-icons medium">desktop_windows</i>
                <h5>Paket 3</h5>
                <strong>Rp 1.500.000</strong>
                <p>Gratis Domain .com, .co.id</p>
              <p>Hosting 3GB (90 foto kuota kerja)</p>
              <p>Free Banner dan Logo</p>
              <p>Integrasi Media Sosial</p>
              <p></p>
              <p>Pemasangan Google Map</p>
              <p>Free Whatsapp/Telepon</p>
              <p>Website SSL</p>
              <p>Template WP Premium</p>
              <p>Standart Kontak Form</p>
              <p>Plugin premium</p>
              <p>Perpanjangan Setiap Tahun Rp 700.000</p>
              <p>Bandwidth Unlimited</p>
              <p>Free support</p>
              <a class="btn blue darken-2" target="_blank" href="http://wa.me/081513460378?text=Saya%20mau%20beli%20paket%203">Hubungi Teknisi</a>
            </div>

          </div>

      </div>
    </div>
  </section>

				
				
			</div>
			
		</div>
		<?php require 'footer.php';?>