<?php 

require_once 'koneksi.php';
if (!isset($_GET['id']) || $_GET['id'] == '') header('Location: index.php');
$id = $_GET['id'];
$query = mysqli_query($koneksi, "SELECT * FROM tbl_artikel WHERE id_kategori = $id");
$query_kategori_artikel = mysqli_query($koneksi, "SELECT nama_kategori FROM tbl_kategori_artikel WHERE id = $id");
$kategori_artikel = mysqli_fetch_assoc($query_kategori_artikel);

$all_kategori_artikel= mysqli_query($koneksi, "SELECT * FROM tbl_kategori_artikel LIMIT 4");
$aktif = 'artikel';
?>

		<!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
	  <link rel="stylesheet" href="resources/fonts/stylesheet.css">
    <link rel="icon" type="icon" href="img/g.png"> 
      <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <style>
        .slider h3,
        .slider h5,
        .clients h3 {
          text-shadow: 1px 1px 3px rgba(0,0,0,0.5);
      }
      .parallax-container {
        height: 240px;
      }
      .parallax img{
        filter: grayscale(1);
        opacity: 0.5 !important;
      }
      section{
        padding:20px 0;
      }
      </style>
      <title>Jericho</title>
    </head>

    <body>
      
      <!-- Navbar -->
       <div class="navbar-fixed">
    <nav class="blue darken-2">
      <div class="container"> 
      <div class="nav-wrapper">
        <a href="#!" class="brand-logo">Jericho</a>
        <a href="#" data-target="mobile-nav" class="sidenav-trigger"><i class="material-icons">menu</i></a>
        <ul class="right hide-on-med-and-down">
          <?php include 'navbar.php'; ?>
        </ul>
      </div>
    </nav>
  </div>
</div>


		<!-- nav bar -->
		<?php require_once 'navbar.php'; ?>


		<!-- content -->
<section class="article" id="article">
    <div class="container">
      <div class="row">
		  <h3 class="center ligth"><?= $kategori_artikel['nama_kategori'] ?></h3>
		  <hr>
		  <table class="table-bordered">
			<tr>
				<th class="center">Kategori</th>
			</tr>
			<tr>
				<td class="center">
				<a href="artikel.php" class="waves-effect waves-light btn"><span><<</span>Semua artikel</a>
				<?php while($all_kategori = mysqli_fetch_assoc($all_kategori_artikel)) : ?>
				 <a href="kategori.php?id=<?= $all_kategori['id'] ?>" class="waves-effect waves-light btn"><?= $all_kategori['nama_kategori'] ?></a> 
				<?php endwhile; ?>
				</td>
			</tr>
		</table>
        <div class="col s12 m7">
		<?php while($artikel = mysqli_fetch_assoc($query)) : ?>
		<div class="card">
			<div class="card-image">
			<img src="images/artikel/<?= $artikel['foto'] ?>">
			</div>
			<div class="card-content">
			<h5><?= $artikel['judul']; ?></h5>
			<h6><b><?= date('d M y', strtotime($artikel['tanggal'])) ?></b></h6>
			<p><?= substr($artikel['isi'], 0, 150) . '...' ?></p>
			</div>
			<div class="card-action black">
			<a href="detail_artikel.php?id=<?= $artikel['id'] ?>">Lihat Artikel</a>
			</div>
		</div>
		<?php endwhile; ?>

	

      </div>
		
    </div>
  </section>

				
				
			</div>
			
		</div>
		<?php require 'footer.php';?>